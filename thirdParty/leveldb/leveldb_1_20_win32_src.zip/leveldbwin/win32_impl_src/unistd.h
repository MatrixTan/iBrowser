
#ifndef _UNISTD_H_
#define _UNISTD_H_

#define strdup _strdup

#endif